package example;
//面向对象编程的基本组成
public class exa_3_1 {                          //类体声明
    private String name;                     //私有变量声明，带有默认初值
    public void setName(String name){       //公有方法，设置或更改成员变量的值
    	this.name=name;
    }
    public String getName(){                //公有方法，取得成员变量的值
    	return this.name;
    }
    public void print(){           //公有方法，屏幕输出
    	System.out.println("Person's name is "+this.getName());
    }
	public static void main(String[] args) {
		exa_3_1 person=new exa_3_1();//创建类对象
		person.setName("zhangsan");//对象调用成员方法
		person.print();

	}

}
