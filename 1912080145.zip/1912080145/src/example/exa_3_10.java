package example;
//多态代替重载
class Triangle extends exa_3_10{
	
	public int getSides(){	//重写
	  	return 3;
	}
}
class Rectangle extends exa_3_10{
	public int getSides(int i) { //重载
		return i;
	}
}

public class exa_3_10 {
	
     public boolean isSharp() {
		return true;
	}
	public int getSides(){ //重载
		return 0;
		
	}
	public int getSides(Triangle tri) { //重载
		return 3;
		
	}
	public int getSides(Rectangle rec) { //重载
		return 4;
		
	}
	public static void main(String[] args) {
		Triangle tri=new Triangle();
		//继承
		System.out.println("Triangle is a type of sharp?"+tri.isSharp());
		exa_3_10 shape=new Triangle(); //多态
        //多态
		System.out.println("My shape has "+shape.getSides()+" sides.");
	}

}
