package example;
//继承与多态
class Aab{
	int i;
	public void getA(int i) {
		System.out.println("i="+i);
	}
}
class Bab extends Aab{
	int i;
	public void getB(int i) {
		getA(1);
		System.out.println("i="+i);
		System.out.println("i="+i);   //调用的是c中的方法
	}
}
class Cab extends Bab{
	int i;
	public void getC(int i) {
		getB(1);
		System.out.println("i="+i);
	}
	public void getA(int i) {//覆盖了 classA中的方法
		System.out.println("i="+i);
		System.out.println("i="+i);
	}
}
public class exa_3_12{
	
	public static void main(String[] args) {
	Bab c=new Cab();
		//a.getA(1);
	c.getB(3);
	}
}

