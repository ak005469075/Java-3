package example;
//实例成员变量,方法参数之间的关系
class Parent{
	int i=10;  //父类变量
	public void setI(int i) {
		this.i=i;
	}
	public int getI(int i) {
		return this.i; //如果改为return i;   后两行值为200；
	}
}
public class exa_3_13 extends Parent{
    int i=11;  //子类与父类同名的变量
    public void setI(int i) {
		this.i=i;
	}
	public static void main(String[] args) {
		exa_3_13 son=new exa_3_13();
		System.out.println("son.i="+son.i);
		son.setI(100);
		System.out.println("After setI(100) : son.i="+son.i);
		Parent parent=son;
		System.out.println("See son as Parent : parent.i="+parent.i);
		System.out.println("See son as Parent : son.i="+son.i);
		System.out.println("See son as Parent : son.getI(200)="+son.getI(200));
		System.out.println("See son as Parent : new Parent().getI(200)="+new Parent().
		getI(200));

	}

}
