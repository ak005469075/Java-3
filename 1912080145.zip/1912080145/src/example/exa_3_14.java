package example;
//实例成员内部类
public class exa_3_14 {
   private static int i=1;
   private int j=10;
   private int k=20;
   public static void outer_f1() {
	   
   }
	   public void outer_f2() {
		   
	   }
	   class Inner{      //实例成员内部类中,可以访问外部类的所有成员
		  //static int inner_i=100; //实例成员内部类中不允许定义静态变量
		   int j=100;
		   int inner_i=1;
		   void inner_f1() {
			   int j=200;
			   System.out.println(i);
			   System.out.println(j); //局部变量j=200
			   System.out.println(this.j); //在内部类中访问内部类自己的变量
			                               //用this.变量名
			   System.out.println(exa_3_14.this.j); //在内部类中访问外部类
			               //中与内部类同名的实例变量用外部类名.this.变量名
			   System.out.println(k); //如果内部类中没有与外部类同名的变量
			                      //就可以直接用变量名访问外部类变量
			   outer_f1();
			   outer_f2();
		   }
		   
	   }              //内部类结束
   public void outer_f3() {
	                //外部类的实例方法访问实例成员内部类,可以直接创建
	               //实例成员内部类的对象
	   Inner inner=new Inner();
	   inner.inner_f1();
   }
   /*外部类的静态方法访问实例成员内部类,与在外部类外部访问成员内部类一样*/
   /*需先创建外部类的对象*/	
   public static void outer_f4(){
			exa_3_14 out=new exa_3_14(); //建立外部类对象
			Inner inner=out.new Inner();    //根据外部类对象建立内部类对象
			inner.inner_f1();  // 访问内部类的方法
		}
	public static void main(String[] args) {
	 outer_f4();

	}

}
