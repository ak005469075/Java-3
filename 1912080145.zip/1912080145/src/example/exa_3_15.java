package example;
//显示返回内部类引用
class Outer{
	private int index=10;
	class Inner{
		private int index=20;
		void print() {
			int index=30;
			System.out.println(index);
			System.out.println(this.index);
			System.out.println(Outer.this.index);
		}
	}
	Inner getInner() {
		return new Inner(); //返回一个内部内的引用
	}
}
public class exa_3_15 {
      public static void main(String[] args) {
    	  Outer outer =new Outer();
    	  /*在另一个类中必须先创建外部类对象,由它创建内部内对象*/
    	  Outer.Inner inner=outer.getInner();
    	  inner.print();
      }
}
//               Inner是Outer的内部内，所以在类exa_3_15中必须用属性引用符来标识出内部类