package example;
// main()方法在Outer类(此时为exa_3_16类)内部
public class exa_3_16 {
     private  int index=10;
     class Inner{
    	 private int index=20;
    	 void print() {
    		 int index=30;
    		 System.out.println(index);
    		 System.out.println(this.index);
    		 System.out.println(exa_3_16.this.index);
    	 }
     }
     Inner getInner() {
    	 return new Inner();   //返回一个内部类的引用
     }
	public static void main(String[] args) {
		exa_3_16 outer=new exa_3_16();
		Inner inner=outer.getInner();  //因为main()是静态方法，需用外部类
		inner.print(); //对象创建内部类对象

	}

}
// 因为main()方法在Outer(即exa_3_16)内部，故可以直接引用Inner,不需要属性引用符exa_3_16.Inner.