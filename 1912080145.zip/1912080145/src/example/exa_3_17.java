package example;
//在main方法中直接产生内部类对象
class exa_3_17 {
	public static void main(String[] args) {
		exa_3_16 outer=new exa_3_16();
		exa_3_16.Inner inner=outer.new Inner(); //注意此处变化
		inner.print();

	}

}
