package example;

public class exa_3_18 {
      int num=10;
      public void print(final int aArgs) {
    	  class Inner{   //类定义在方法中
    		  int num=20; //可以定义和外部类同名的变量,但静态变量不可定义
    		  public Inner() {
    			  System.out.println("This is Inner .");
    			  //可以看出它与匿名内部类用法不同
    		  }
    		  public void print() {
    			  int num=30;
    			  System.out.println(this);// the object created from the local Inner
    			  System.out.println(num);
    			  System.out.println(this.num);
    			  System.out.println(exa_3_18.this.num);
    			  System.out.println(aArgs);  //可以访问外部类的final修饰的局部变量
    			  
    		  }
    	  } //内部类结束
    	  //在外部类中访问内部类,下句必须放在定义类Inner的后面
    	     Inner inner=new Inner();
    	     inner.print();
      }
      
	public static void main(String[] args) {
		exa_3_18 outer=new exa_3_18();
		outer.print(40);
	}

}
