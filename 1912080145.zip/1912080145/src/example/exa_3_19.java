package example;
// 匿名内部类
abstract class Aq{
	abstract public void sayHello();
}
public class exa_3_19 {
	public static void main(String[] args) {
		new exa_3_19().callInner(new Aq() { //从内部类开始
			public void sayHello() {
				System.out.println(this);
				         // the object created from the anonymous Inner
				System.out.println("Hello!");
				
			}
		});      //内部类结束

	}
	public void callInner(Aq a) {
		a.sayHello();
	}

}
