package example;
//传值与传址
public class exa_3_2 {
   public static void change(StringBuffer ia){
    	ia.append("ok?");
    	//append()是StringBuffer类中的方法，字符串ia后面 附加 "ok"
    }
     public static void change(int li){
    	 li=10;
     }
	public static void main(String[] args) {
		StringBuffer a=new StringBuffer("ok");
		//StringBuffer是定义字符串的类，在此定义字符串a="ok"
		int i;
		i=5;
		System.out.println("Before change, a is "+a);
		change(a);
		System.out.println("After change a is "+a);
		System.out.println("Before change i is "+i);
		change(i);
		System.out.println("After change i is "+i);

	}
 
}
