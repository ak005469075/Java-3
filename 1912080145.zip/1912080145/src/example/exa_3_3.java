package example;
//访问权限
public class exa_3_3 {
     static int i;
     protected int j;
     protected static int j1;
     private static int k;
     public static int m;
}

