package example;

public class exa_3_3_1 extends exa_3_3{ //继承exa_3_3
           void limit()
           {
        	   exa_3_3.i++;//i在本包内可访问
        	   exa_3_3.j1--;//j在本包或子类中可访问
        	   //exa_3_3.k++;  //exa_3_3的私有成员在另一个类中不能访问
        	   exa_3_3.m--;//公有权限，任何地方都可以访问
           }
}

