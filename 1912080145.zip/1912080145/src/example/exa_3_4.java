package example;
//继承
class SuperClass{
	private int i=1;
	int j=2;
	int plus(){
		return i+j;
	}
}
class SubClass extends SuperClass{
	int i=10,j=20;//覆盖父类
	int subduce(){
		return j-super.j;//super.j,父类的j
	}
}
public class exa_3_4 {
     
	public static void main(String[] args) {
		SuperClass sup=new SuperClass();
		SubClass sub=new SubClass();
		SuperClass supsub=new SubClass();//上转型，定义变量是父类，对象是子类
		//System.out.println("sup.i="+sup.i); //i在别的类中不可见
		System.out.println("sup.plus()="+sup.plus());
		 //调用A中的plus(),i此时在plus()中可以调用
		System.out.println("sub.plus()="+sub.plus());
				//继承A中的plus(),i为A中的
		System.out.println("supsub.plus()="+supsub.plus());
		        //调用B中继承自A中的plus(),i为A中的
	}

}
