package example;
//实例变量和实例方法的隐藏和覆盖
	class A{
		int i=1;
		int j=2;
		int plus(){
			return i+j;
		}
	}
	class B extends A{
		int i=10,k=20;//i与父类同名，隐藏了父亲的i
		int plus(){
			return i+j+k;//覆盖了父亲的同名方法
		}
	}
	public class exa_3_5{
	     
		public static void main(String[] args) {
			A a=new A();
			B b=new B();
			A c=new B();//上转型，定义变量是父类，对象是子类
			System.out.println("a.i="+a.i+","+"a.j="+a.j+","+"a.plus()="+a.plus());
			  //调用A中的plus(),i为A中的
			System.out.println("b.i="+b.i+","+"b.j="+b.j+","+"b.k="+b.k+","+"b.plus()="+b.plus());
			 //调用B中的plus(),i为B中的
			//System.out.println("c.i="+c.i+","+"c.j="+c.j+","+"c.k="+c.k+","+"c.plus()="+c.plus());
					//k是B中增加的,上转型对象只能调用重写的
			System.out.println("c.i="+c.i+","+"c.j="+c.j+","+"c.plus()="+c.plus());
			        //调用B中的plus(),i为A中的
		}
		
	}


