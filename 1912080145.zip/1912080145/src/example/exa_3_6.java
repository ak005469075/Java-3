package example;
//静态变量和静态方法的隐藏
class A2{
	static int i=1,j=2;
	static int plus(){ //如果将static去掉不行，静态的不能覆盖实例的
		return i+j;
	}
}
class B2 extends A2{
	 static int i=10,k=20; //i与父类同名,隐藏了父类的i
	 static int plus(){
		   /*覆盖了父类的同名方法，如果将static去掉不行，实例的不能覆盖静态的*/
		 return i+j+k;
	 }
}
public class exa_3_6 {

	public static void main(String[] args) {
		A2 a=new A2();
		B2 b=new B2();
		A2 c=new B2();
		System.out.println("a.i="+a.i+","+"a.j="+a.j+","+"a.plus()="+a.plus());
		          //调用A中plus(),i为A中的
		System.out.println("b.i="+b.i+","+"b.j="+b.j+","+"b.k="+b.k+","+"b.plus()="+b.plus());
		         //调用B中的plus(),i为B中的
		//System.out.println("c.i="+c.i+","+"c.j="+c.j+","+"c.k="+c.k+","+"c.plus()="+c.plus());
		     //k是B中增加的，上转型对象只能调用重写的
		System.out.println("c.i="+c.i+","+"c.j="+c.j+","+"c.plus()="+c.plus());
                 //调用B中的plus(),i为A中的
	}

}
