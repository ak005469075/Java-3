package example;
//对象初识化顺序
  class Father{
	private String name="FATHER";
	private int i=1;
	public Father(){
		whoAmI();
		tellName(name);
		tellValue(i);
	}
	public void whoAmI(){
		System.out.println("Father says,I am "+name+",i="+i);
	}
	public void tellName(String name){
		System.out.println("Father's name is "+name+",i="+i);
	}
	public void tellValue(int i){
		System.out.println("Father's name is "+name+",i="+i);
	}
}
  class Son extends Father{
	   private String name="SON";
	   private int i=2;
	   public Son(){
		   whoAmI();
		   tellName(name);
		   tellValue(i);
	   }
	   public void whoAmI(){
			System.out.println("Son says,I am "+name+",i="+i);
		}
		public void tellName(String name){
			System.out.println("Son's name is "+name+",i="+i);
		}
		public void tellValue(int i){
			System.out.println("Father's name is "+name+",i="+i);
		}
  }
public class exa_3_7 {

	public static void main(String[] args) {
		// Father f1=new Father();
		//Son s=new Son();
		Father f = new Son();
		System.out.println(f);

	}

}
