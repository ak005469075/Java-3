package example;
//构造方法的调用
public class exa_3_8 {

	public static void main(String[] args) {
		BB b=new BB(0);
		int y=b.getY();

	}

}
class AA{
	public static int x=2;
	private int y=2;
	protected int z;
	AA(){
		x=x+1;
		showX();
	}
	public void showX(){
		System.out.println("AA.x="+x);
	}
	public int getY(){
		return y;
	}
}
class BB extends AA{
	BB(int x){
		x=x+2; //只对局部x操作
		showX();
	}
	public void showX(){
		System.out.println("BB.x="+x);
	}
	public int getY(){
		System.out.println("BB.y="+(super.getY()+x));
		return super.getY()+x;
	}
	
}
