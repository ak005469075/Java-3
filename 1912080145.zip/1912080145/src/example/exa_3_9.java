package example;
//方法调用的优先顺序
class Ab{
	public String show(D obj) {
		 return ("A and D");
	}
	public String show(Ab obj) {
		return ("A and A");
	}
	public String show(C obj) {
		return ("A and C");
	}
}
class Ba extends Ab{
	public String show(Ba obj) {
		 return ("B and B");
	}
	public String show(Ab obj) {
		return ("B and A");
	}
	public String show(C obj) {
		return ("B and C");
	}
}
class C extends Ba{
	
}
class D extends Ba{
	
}
public class exa_3_9 {
     public static void main(String[] args) {
    	 Ab a1=new Ab();
    	 Ab a2=new Ba();
    	 Ba b=new Ba();
    	 C c=new C();
    	 D d=new D();
    	 System.out.println(a1.show(b)); //1
    	 System.out.println(a1.show(c)); //2
    	 System.out.println(a1.show(d)); //3
    	 System.out.println(a2.show(b)); //4
    	 System.out.println(a2.show(c)); //5
    	 System.out.println(a2.show(d)); //6
    	 System.out.println(b.show(b)); //7
    	 System.out.println(b.show(c)); //8
    	 System.out.println(b.show(d)); //9
    	 
     }
}
