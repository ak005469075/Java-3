package example1;
import example.*;
public class exa_3_3_2 extends exa_3_3{
            void limit(){
            	//exa_3_3.i++;//i在另一个包中不能访问
            	j++;//父类实例成员j,可继承
            	super.j++;//父类实例成员j,用super可调用
            	
            	exa_3_3.j1--;//父类static成员j1，用类名可调用
            	j1++;//父类static成员j1,可继承
            	
            	//exa_3_3.k++; //exa_3_3的私有成员只能在本类中访问
            	exa_3_3.m--;//公有权限,任何地方都可访问
            }
	public static void main(String[] args) {
	      exa_3_3 sup=new exa_3_3();
	      //System.out.println(sup.j++);//父类实例成员j,用对象不可调用
	      //sup.limit();//父类实例成员j,用对象不可调用
	      System.out.println(sup.j1++);////父类static成员j1,用对象却可调用
	}

}
