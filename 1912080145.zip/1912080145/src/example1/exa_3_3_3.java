package example1;
import example.*;
public class exa_3_3_3 {
     void lim()
     {
    	  // exa_3_3.i++;//i在另一个包中不可访问
    	   //exa_3_3.j1--;//j在外包或不是子类中，不可访问
    	   //exa_3_3.k++;  //exa_3_3的私有成员只能在本类中访问
    	   exa_3_3.m--;//公有权限，任何地方都可以访问
     }
}
