package exercise;
import java.util.Scanner;
//用圆类创建一个对象，求圆的面积和周长
public class exer3_1 {
    private double r;
    public void setR(double r){
    	this.r=r;
    }
    public double getR(){
    	return this.r;
    }
    public double getC()
    {
    	return this.r*2*3.14;
    }
    public double getA()
    {
    	return this.r*this.r*3.14;
    }
    public void print()
    {
    	System.out.println("半径为"+this.r+"的圆，周长为"+getC()+",面积为"+getA());
    }
	public static void main(String[] args) {
		Scanner str=new Scanner(System.in);
		exer3_1 circle=new exer3_1();
         System.out.println("请输入半径:");
         circle.r=str.nextInt();
         circle.print();
         str.close();
	}

}
