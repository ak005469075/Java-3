package exercise;
//定义Employee类，其中包括姓名、性别、出生日期和工资，
//输入个人信息，并在控制台中输出。
import java.util.Scanner;
public class exer3_2 {
    private String name;
    private String sex;
    private int birthdate;
    private int salary;
    public void setName(String name)
    {
    	this.name=name;
    }
    public void setSex(String sex)
    {
    	this.sex=sex;
    }
    public void setBirthdate(int birthdate){
    	this.birthdate=birthdate;
    }
    public void setSalary(int salary){
    	this.salary=salary;
    }
    public String getName()
    {
    	return this.name;
    }
    public String getSex()
    {
    	return this.sex;
    }
    public int getBirthdate(){
    	return this.birthdate;
    }
    public int getSalary(){
    	return this.salary;
    }
    public void print()
    {
    	System.out.println("姓名:"+getName());
    	System.out.println("性别:"+getSex());
    	System.out.println("出生日期:"+getBirthdate());
    	System.out.println("工资:"+getSalary());
    }
	public static void main(String[] args) {
		exer3_2 employee=new exer3_2();
		Scanner str=new Scanner(System.in);
		System.out.print("请输入姓名:");
		employee.setName(str.next());
	  System.out.print("请输入性别(男:m,女:f):");
	  //char getchar=str.nextLine().charAt(0);//使得string类转为char;
		employee.setSex(str.next());//
		System.out.print("请输入出生日期(例:19890511):");
		employee.setBirthdate(str.nextInt());
		System.out.print("请输入工资:");
		employee.setSalary(str.nextInt());
		employee.print();
		str.close();

	}

}
