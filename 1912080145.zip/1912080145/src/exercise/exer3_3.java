package exercise;
//模拟一个银行账户类Account，
//账户类中包括所有者、账号、余额、账户总数、存款、取款等信息。
public class exer3_3 {
   private String owner;
   private int number;
   private int yue;
   private int people;
   private int save;
   private int remove;
   public void setAccount(String owner,int number,
	                                   int yue,
                                       int people,
                                       int save,
                                       int remove){
	   this.owner=owner;
	   this.number=number;
	   this.yue=yue;
	   this.people=people;
	   this.save=save;
	   this.remove=remove;
   }
   public String getOwner()
   {
	   return this.owner;
   }
   public int getNumber()
   {
	   return this.number;
   }
   public int getYue()
   {
	   return this.yue;
   }
   public int getPeople()
   {
	   return this.people;
   }
   public int getSave()
   {
	   return this.save;
   }
   public int getRemove()
   {
	   return this.remove;
   }
   public void print()
   {
	   System.out.println("账户所有者:"+getOwner());
	   System.out.println("账户账号:"+getNumber());
	   System.out.println("账户余额:"+getYue());
	   System.out.println("账户户口:"+getPeople());
	   System.out.println("存款:"+getSave());
	   System.out.println("取款:"+getRemove());
   }
	public static void main(String[] args) {
		exer3_3 Account=new exer3_3();
		Account.setAccount("吴某某",198789745,500000000,3,89789789,45454545);
        Account.print();
	}

}
